from utils import count_codes
import sys

def count200():
    sys.stdout.write(str(count_codes("302")))

if __name__ == "__main__":
    count200()